module.exports = {
   DB: 'mongodb://${aib.getParam('mongodb.server address')}/${aib.getParam('mongodb.database name')}'
};