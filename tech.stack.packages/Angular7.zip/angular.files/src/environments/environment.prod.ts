export const environment = {
  production: true,
  angularPort: 4000
};
