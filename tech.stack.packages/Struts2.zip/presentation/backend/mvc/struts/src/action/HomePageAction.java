#header()
package ${aib.getRootPackageName()}.#getActionPackageName();


/**
 * General Home Page Action.
 
 * @author $aib.getAuthor()
 */
public class HomePageAction extends BaseStrutsAction
{
    
//************************************************************************    
// Public Methods
//************************************************************************
}



