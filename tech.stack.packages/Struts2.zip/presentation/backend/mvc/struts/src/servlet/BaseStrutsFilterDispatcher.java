#header()
package ${aib.getRootPackageName()}.#getServletPackageName();

	
public class BaseStrutsFilterDispatcher extends FrameworkBaseStrutsFilterDispatcher 
{
}


