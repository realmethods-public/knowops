#header()
package ${aib.getRootPackageName()}.#getServletPackageName();

import ${aib.getRootPackageName()}.persistent.FrameworkPersistenceHelper;

import java.util.logging.Level;
import java.util.logging.Logger;

import javax.servlet.*;
import javax.servlet.http.*;


public class FrameworkBaseStrutsFilterDispatcher
    extends org.apache.struts2.dispatcher.filter.StrutsPrepareAndExecuteFilter
{
}
