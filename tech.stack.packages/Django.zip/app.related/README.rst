#set( $appName = $aib.getApplicationNameFormatted() )
#set( $description = $aib.getParam("application.description") )

=====
$appName
=====

$description


Quick start
-----------

After downloading (pulling) this application's files, start your local development server and visit the app at http://127.0.0.1:8000/admin/
to begin creating the business entities from the model used to create this application.

